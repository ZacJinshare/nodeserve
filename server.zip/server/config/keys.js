module.exports = {
  mongoURI: 'mongodb://jinshare:hacTEfpaJRDy05VX@124.221.179.102:27017/nodesv',
  secretOrKey: 'secret'
};
