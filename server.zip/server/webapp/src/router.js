import Vue from 'vue'
import Router from 'vue-router'
import Index from './views/Index.vue'
import Register from './views/Register'
import Nofind from './views/404'
import Login from './views/Login'
import Home from './views/Home'
import InfoShow from './views/InfoShow'
import FoundList from './views/FoundList'
import Excel from './views/Excel'
import Shuiw from './views/Shuiw'
import Wulian from './views/Wulian'
import Suyuan from './views/Suyuan'
import Gh from './views/Gh'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    { path: '*', name: '/404', component: Nofind },
    { path: '/', redirect: '/index' },
    { path: '/register', name: 'register', component: Register },
    { path: '/login', name: 'login', component: Login },
   
    {
      path: '/index',
      name: 'index',
      component: Index,
      children: [
        { path: '', component: Home },
        { path: '/home', name: 'home', component: Home },
        { path: '/infoshow', name: 'infoshow', component: InfoShow },
        { path: '/foundlist', name: 'foundlist', component: FoundList },
        { path: '/excel', name: 'excel', component: Excel },
        { path: '/shuiz', name: 'shuiz', component: Shuiw },
        { path: '/wulian', name: 'wulian', component: Wulian },
        { path: '/suyuan', name: 'suyuan', component: Suyuan },
        { path: '/gh', name: 'gh', component: Gh },
        { path: '/qukuai', name: 'qukuai', component: () => import('./views/Qukuai.vue')},
        { path: '/node', name: 'node', component: () => import('./views/Node.vue')},
      ]
    },

    // {
    //   path: '/about',
    //   name: 'about',
    //   // route level code-splitting
    //   // this generates a separate chunk (about.[hash].js) for this route
    //   // which is lazy-loaded when the route is visited.
    //   component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    // }
  ]
})

//添加路由守卫
router.beforeEach((to, from, next) => {
  const isLogin = localStorage.eleToken ? true : false;
  if (to.path == "/login" || to.path == "/register") {
    next();
  } else {
    isLogin ? next() : next("/login");
  }
})

export default router;