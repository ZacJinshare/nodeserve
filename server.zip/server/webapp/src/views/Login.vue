<template>
  <div class="login" ref='login'>
    <div class="container">
      <div class="form-box" ref="formbox">
        <!-- 注册 -->
        <div class="register-box hidden" ref="registerbox">
          <h1>注册</h1>
          <input type="text" placeholder="用户名" />
          <input type="email" placeholder="邮箱" />
          <input type="password" placeholder="密码" />
          <input type="password" placeholder="确认密码" />
           <input type="text" placeholder="默认角色：售后" />
          <button>注册</button>
        </div>
        <!-- 登录 -->
        <div
          class="login-box"
          :model="loginUser"
          ref="loginForm"
        >
          <h1>登录</h1>
      
          <input
            class="ipt"
            type="email"
            v-model="loginUser.email"
            placeholder="请输入邮箱"
          />
          
          <input
            type="password"
            v-model="loginUser.password"
            placeholder="密码"
          />
        
          <button @click="submitForm(loginUser)">登录</button>
           
        </div>
      </div>
      <div class="con-box left">
        <h2>欢迎使用<span>工业Saas</span></h2>
        <p>您同时将了解<span>区块链</span>是什么</p>
        <img src="../assets/zz.jpg" alt="" />
        <p>已有账号</p>
        <button id="login" @click="tologin">去登录</button>
      </div>
      <div class="con-box right">
        <h2>欢迎使用<span>工业Saas</span></h2>
        <p>您同时将了解<span>区块链</span>是什么</p>
        <img src="../assets/tt.jpg" alt="" />
        <p>没有账号？</p>
        <button id="register" @click="toregister">去注册</button>
      </div>
    </div>
  </div>
</template>

<script>
import jwt_decode from "jwt-decode";
export default {
  name: "login",
  data() {
    return {
      loginUser: {
        email: "",
        password: "",
      }
    };
  },
  methods: {
    toregister() {
      this.$refs.formbox.style.transform = "translateX(80%)";
      this.$refs.loginForm.classList.add("hidden");
      this.$refs.registerbox.classList.remove("hidden");
    },
    tologin() {
      this.$refs.formbox.style.transform = "translateX(0%)";
      this.$refs.registerbox.classList.add("hidden");
      this.$refs.loginForm.classList.remove("hidden");
    },
    submitForm(loginUser) {
        if (loginUser.email&&loginUser.password) {
          this.$axios.post("/api/users/login", this.loginUser).then((res) => {
            // 登录成功
            const { token } = res.data;
            localStorage.setItem("eleToken", token);

            // 解析token
            const decode = jwt_decode(token);

            // 存储数据
            this.$store.dispatch("setIsAutnenticated", !this.isEmpty(decode));
            this.$store.dispatch("setUser", decode);

            // 页面跳转
            this.$router.push("/index");
          });
        } else {
          alert("不能留空!!");
          return false;
        }
    },
    isEmpty(value) {
      return (
        value === undefined ||
        value === null ||
        (typeof value === "object" && Object.keys(value).length === 0) ||
        (typeof value === "string" && value.trim().length === 0)
      );
    },
  },
};
</script>

<style scoped>
.login {
  position: relative;
  width: 100%;
  height: 100%;
  background: url(../assets/bg.jpg) no-repeat center center;
  background-size: 100% 100%;
}
.loginForm {
  margin-top: 20px;
  background-color: #fff;
  padding: 20px 40px 20px 20px;
  border-radius: 5px;
  box-shadow: 0px 5px 10px #cccc;
}

.submit_btn {
  width: 100%;
}
.tiparea {
  text-align: right;
  font-size: 12px;
  color: #333;
}
.tiparea p a {
  color: #409eff;
}
.container {
  background-color: #fff;
  width: 650px;
  height: 415px;
  border-radius: 5px;
  /* 阴影 */
  box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1);
  /* 相对定位 */
  position: relative;
  margin: 0 auto;
  top: 180px;
}
.form-box {
  /* 绝对定位 */
  position: absolute;
  top: -10%;
  left: 5%;
  background-color: #85ccf3;
  width: 320px;
  height: 500px;
  border-radius: 5px;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2;
  /* 动画过渡 加速后减速 */
  transition: 0.5s ease-in-out;
}
.register-box,
.login-box {
  /* 弹性布局 垂直排列 */
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}
.hidden {
  display: none;
  transition: 0.5s;
}
h1 {
  text-align: center;
  margin-bottom: 25px;
  /* 大写 */
  text-transform: uppercase;
  color: #fff;
  /* 字间距 */
  letter-spacing: 5px;
}
input {
  background-color: transparent;
  width: 70%;
  color: #fff;
  border: none;
  /* 下边框样式 */
  border-bottom: 1px solid rgba(255, 255, 255, 0.4);
  padding: 10px 0;
  text-indent: 10px;
  margin: 8px 0;
  font-size: 14px;
  letter-spacing: 2px;
}
input::placeholder {
  color: #fff;
}
input:focus {
  color: #0b5d97;
  outline: none;
  border-bottom: 1px solid #0873bb80;
  transition: 0.5s;
}
input:focus::placeholder {
  opacity: 0;
}
.form-box button {
  width: 70%;
  margin-top: 35px;
  background-color: #f6f6f6;
  outline: none;
  border-radius: 8px;
  padding: 13px;
  color: #048acd;
  letter-spacing: 2px;
  border: none;
  cursor: pointer;
}
.form-box button:hover {
  background-color: #045b8a;
  color: #f6f6f6;
  transition: background-color 0.5s ease;
}
.con-box {
  width: 50%;
  /* 弹性布局 垂直排列 居中 */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* 绝对定位 居中 */
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
.con-box.left {
  left: -2%;
}
.con-box.right {
  right: -2%;
}
.con-box h2 {
  color: #8e9aaf;
  font-size: 25px;
  font-weight: bold;
  letter-spacing: 3px;
  text-align: center;
  margin-bottom: 4px;
}
.con-box p {
  font-size: 12px;
  letter-spacing: 2px;
  color: #8e9aaf;
  text-align: center;
}
.con-box span {
  color: #1b8fcd;
}
.con-box img {
  width: 150px;
  height: 150px;
  opacity: 0.9;
  margin: 40px 0;
}
.con-box button {
  margin-top: 3%;
  background-color: #fff;
  color: #1892be;
  border: 1px solid #04649f;
  padding: 6px 10px;
  border-radius: 5px;
  letter-spacing: 1px;
  outline: none;
  cursor: pointer;
}
.con-box button:hover {
  background-color: #0bb0de;
  color: #fff;
}
</style>


