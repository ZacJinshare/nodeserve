<template>
  <div>
    <h2>溯源系统——区块链简化演示</h2>

    <div class="block">
      <el-timeline>
        <el-timeline-item
          v-for="(activity, index) in activities"
          :key="index"
          :icon="activity.icon"
          :type="activity.type"
          :color="activity.color"
          :size="activity.size"
          :timestamp="activity.timestamp"
        >
          {{ activity.content }}
          <p>操作方：{{ activity.user }}</p>
        </el-timeline-item>
      </el-timeline>

      <div class="role">您当前的权限: &nbsp;&nbsp; <b>审核</b></div>
      <el-button type="success" @click="tongguo" >审核通过</el-button>
      <el-button type="danger" @click='fangong'>驳回返工</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activities: [
        {
          content: "售前分发",
          user: "工厂环节：售前规划员XXX",
          timestamp: "- - -",
        },
        {
          content: "入库审核---等待处理",
          user: "工厂环节：审核员 娄大叔",
          timestamp: "- - -",
          size: "large",
          type: "primary",
          icon: "el-icon-more",
          color: "red",
        },
        {
          content: "质检",
          user: "工厂环节：质检员XXX",
          timestamp: "2022-04-09 20:46",
          color: "#0bbd87",
        },
        {
          content: "生产环节",
          user: "工厂环节：质检员XXX",
          timestamp: "2022-04-05 20:46",
          color: "#0bbd87",
          size: "large",
        },
        {
          content: "提交生产计划",
          user: "工厂环节：生产计划部分负责人XXX",
          timestamp: "2022-04-03 20:46",
          color: "#0bbd87",
        },
      ],
    };
  },
  methods: {
    tongguo() {
      let time = new Date();
      //驳回 el-icon-close
      let a = this.activities[1];
      let b = this.activities[0];
      a.icon = "el-icon-check";
      a.color = "#0bbd87";
      a.content = "入库审核--已通过";
      a.timestamp = "操作时间：" + time.toString();
      b.color = "red";
      b.icon = "el-icon-more";
      b.content = "售前分发--等待状态";
    },
    fangong(){
      let time = new Date();
      this.activities[1].icon='el-icon-close';
      this.activities[1].content = "入库审核--已驳回";
      this.activities[1].color = "red";
      this.activities[1].timestamp = "操作时间：" + time.toString();
      this.activities[0].icon='';
      this.activities[0].timestamp = "---"
      this.activities[0].color='#ddd' 
       console.table(this.activities)
      
    }
  },
};
</script>

<style scoped>
h2 {
  font-size: 22px;
  padding: 18px;
}
p {
  margin-top: 10px;
}
.block {
  padding: 25px;
  margin-left: 60px;
}
.role {
  padding: 30px;
  color: rgb(155, 1, 52);
}
</style>