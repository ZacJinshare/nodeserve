<template>
  <div>
    <h2>物联网常用通讯方式：RS232/485通讯，Modbus RTU协议。部标808协议、809协议、769标准、794标准。
</h2>
    <img src="../assets/wulian.webp">
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
h2{font-size:22px;padding:18px;}
img{max-width:100%;padding:18px;}
</style>