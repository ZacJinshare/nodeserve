<template>
  <iframe class='ctt' src='http://106.37.208.243:8068/GJZ/Business/Publish/Main.html'></iframe>
</template>

<script>
export default {
name:'Shuiw'
}
</script>

<style scoped>
.ctt{
 margin-top:-60px;
 width:100%;
 height:1800px;
}
</style>