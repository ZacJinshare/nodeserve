<template>
  <div>
    <h2>工业互联网环节图：类似于建设类游戏
</h2>
    <img src="../assets/gh.png">
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
h2{font-size:22px;padding:18px;}
img{max-width:96%;padding:18px;}
</style>