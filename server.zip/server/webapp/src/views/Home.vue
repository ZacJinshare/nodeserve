<template>
  <div class="home">
    <div class="container">
      <h1 class="title">综合管理演示</h1>
      <p class="lead">
        一个SAAS系统演示明白：物联网、工业互联网、区块链与溯源系统(去中心化的思维方式)、Node技术栈!
      </p>
      <p class="lead">系统所用技术栈：Vue(前端)+Nodejs（后端+服务器）+ MongoDB（数据库）</p>
    <div class='imgshow'>
        <router-link to="/shuiz"><img src="../assets/shuiz.jpg"></router-link>
        <router-link to="/excel"><img src="../assets/gongye.jpg"></router-link>
        <router-link to="/shuiz"><img src="../assets/qukuai.jpg"></router-link>
    </div>
    </div>
  </div>
</template>

<style scoped>
.home {
  width: 100%;
  height: 100%;
  background: url(../assets/showcase.png) no-repeat;
  background-size: 100% 100%;
}
.container {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding-top: 100px;
  background-color: rgba(0, 0, 0, 0.7);
  text-align: center;
  color: white;
}
.title {
  font-size: 30px;
}
.lead {
  margin-top: 50px;
  font-size: 22px;
}
.imgshow{
  display: flex;
  margin-top:100px;
}
.imgshow img{
  max-width: 80%;
  border:3px #fff solid;
  border-radius:15px;
}
.imgshow img:hover{
  border:5px rgba(231, 186, 6, 0.996) solid;
  transition: border 0.5s ease;
}
</style>