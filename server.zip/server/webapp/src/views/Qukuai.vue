<template>
  <div>
    <h2>区块链不是一种技术，而是一种思维方式，去中心化的一种管理模式。
</h2>
    <img src="../assets/block.png">
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
h2{font-size:22px;padding:18px;}
img{max-width:100%;padding:18px;}
</style>