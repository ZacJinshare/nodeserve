<template>
  <div>
    <h2>Node技术栈：又快又省，性能强悍，天生适合docker和Serverless。让JavaScript语言逆袭。
</h2>
<span>性能比python和PHP高，能扛得住高并发高负载，极大节省服务器成本。不依赖其他服务器，路径与文件目录无关，更安全！Nodejs是基于谷歌浏览器V8引擎，用C++开发的。</span>
    <p>单线程</p>
    <p>非阻塞I/O</p>
    <p>事件驱动</p>
    <p>阿里Node框架： <a href="http://nodejs.cn/" target='blank'>egg.js</a></p>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
h2{font-size:22px;padding:18px;}
img{max-width:100%;padding:18px;}
span{padding:18px;}
p{margin:15px 15px;
font-weight:bold;
padding:35px;
border:5px rgb(114, 233, 248) solid;
border-radius:18px;
background: rgb(247, 182, 84);
}
</style>